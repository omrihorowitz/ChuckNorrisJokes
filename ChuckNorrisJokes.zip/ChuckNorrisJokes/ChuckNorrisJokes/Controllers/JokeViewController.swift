//
//  JokeViewController.swift
//  ChuckNorrisJokes
//
//  Created by Omri Horowitz on 1/27/21.
//

import UIKit

class JokeViewController: UIViewController {

    
    @IBOutlet weak var categoryLabel: UILabel!
    @IBOutlet weak var chuckImageView: UIImageView!
    @IBOutlet weak var jokeValueLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()
    }
    
    var categories: [String] = []
    
    @IBAction func newJokeButtonTapped(_ sender: Any) {
        updateViews()
}
    func updateViews() {
        fetchCategories()
        guard let category = categories.randomElement() else { return }
        JokeController.fetchJoke(category: category) { (result) in
            DispatchQueue.main.async {
            switch result {
            case .success(let joke):
                self.categoryLabel.text = category.capitalized
                self.jokeValueLabel.text = joke.value
                self.fetchIconAndUpdateViews(joke: joke)
            case.failure(let error):
                self.presentErrorToUser(localizedError: error)
            }
        }
    }
    }
    func fetchCategories() {
        JokeController.fetchCategories { (result) in
            DispatchQueue.main.async {
            switch result {
            case .success(let categories):
                self.categories = categories
            case.failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}

    func fetchIconAndUpdateViews(joke: Joke) {
        JokeController.fetchIcon(for: joke) { (result) in
            DispatchQueue.main.async {
                switch result {
                case .success(let image):
                    self.chuckImageView.image = image
                    self.jokeValueLabel.text = joke.value
                case .failure(let error):
                    self.presentErrorToUser(localizedError: error)
                }
            }
        }
    }
}
