//
//  Joke.swift
//  ChuckNorrisJokes
//
//  Created by Omri Horowitz on 1/27/21.
//

import Foundation

struct Joke: Decodable {
    let icon_url: URL?
    let value: String
    let categories: [String]
}



